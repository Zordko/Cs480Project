package com.example.Cs480Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs480ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
